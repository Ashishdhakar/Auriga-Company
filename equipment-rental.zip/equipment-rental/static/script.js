// Small UX helpers — no framework needed.

document.addEventListener("DOMContentLoaded", function () {
    // Auto-fill "today" for empty date inputs that look like a primary borrow/start date,
    // just as a convenience (user can still change it).
    document.querySelectorAll('input[type="date"]').forEach(function (input) {
        if (!input.value && (input.id === "borrow_date" || input.id === "start_date")) {
            var today = new Date().toISOString().split("T")[0];
            input.setAttribute("min", ""); // no restriction, just a default suggestion
            input.value = today;
        }
    });

    // Auto-dismiss flash messages after a few seconds.
    document.querySelectorAll(".flash").forEach(function (el) {
        setTimeout(function () {
            el.style.transition = "opacity 0.4s ease";
            el.style.opacity = "0";
            setTimeout(function () { el.remove(); }, 400);
        }, 5000);
    });
});
